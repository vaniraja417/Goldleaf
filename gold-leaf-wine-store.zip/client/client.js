// Firebase configuration (same as admin)
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "your-project.firebaseapp.com",
    databaseURL: "https://your-project.firebaseio.com",
    projectId: "your-project",
    storageBucket: "your-project.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();

// DOM Elements
const billingBtn = document.getElementById('billingBtn');
const contentArea = document.getElementById('contentArea');

// Global variables
let currentBillItems = [];
let terminalId = 'B'; // This should be set based on the terminal (B or C)

// Update datetime every second
setInterval(() => {
    document.getElementById('datetime').textContent = new Date().toLocaleString();
}, 1000);

// Event Listeners
billingBtn.addEventListener('click', loadBillingInterface);

function loadBillingInterface() {
    contentArea.innerHTML = `
        <h2>Billing</h2>
        <div id="billingArea">
            <div id="searchArea">
                <input type="text" id="searchInput" placeholder="Search by ID or name">
                <button id="qrScannerBtn">QR Scanner</button>
            </div>
            <table id="itemsTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="itemsTableBody">
                    <!-- Bill items will appear here -->
                </tbody>
            </table>
            <div id="totalArea">
                Grand Total: Rs. <span id="grandTotal">0</span>
            </div>
            <div id="actionButtons">
                <button id="cancelBtn">Cancel</button>
                <button id="printBtn">Print Bill</button>
                <button id="sendToAdminBtn">Send to Admin</button>
            </div>
        </div>
        
        <!-- Quantity Modal -->
        <div id="quantityModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h3>Enter Quantity</h3>
                <input type="text" id="quantityInput" value="1" readonly>
                <div class="number-pad">
                    <button>1</button>
                    <button>2</button>
                    <button>3</button>
                    <button>4</button>
                    <button>5</button>
                    <button>6</button>
                    <button>7</button>
                    <button>8</button>
                    <button>9</button>
                    <button>0</button>
                    <button id="clearBtn">C</button>
                    <button id="enterBtn">Enter</button>
                </div>
            </div>
        </div>
        
        <!-- QR Scanner Modal -->
        <div id="qrScannerModal" class="modal">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h3>QR Scanner</h3>
                <video id="qrVideo" width="100%" height="300"></video>
                <button id="startScannerBtn">Start Scanner</button>
                <button id="stopScannerBtn" disabled>Stop Scanner</button>
            </div>
        </div>
    `;
    
    // Initialize event listeners for billing interface
    document.getElementById('searchInput').addEventListener('keyup', searchItem);
    document.getElementById('qrScannerBtn').addEventListener('click', openQrScannerModal);
    document.getElementById('cancelBtn').addEventListener('click', resetBilling);
    document.getElementById('printBtn').addEventListener('click', printBill);
    document.getElementById('sendToAdminBtn').addEventListener('click', sendToAdmin);
    
    // Quantity modal elements
    const quantityModal = document.getElementById('quantityModal');
    const quantityInput = document.getElementById('quantityInput');
    const closeModal = document.getElementsByClassName('close')[0];
    
    // Number pad buttons
    const numberButtons = document.querySelectorAll('.number-pad button:not(#clearBtn):not(#enterBtn)');
    numberButtons.forEach(button => {
        button.addEventListener('click', () => {
            quantityInput.value += button.textContent;
        });
    });
    
    document.getElementById('clearBtn').addEventListener('click', () => {
        quantityInput.value = '';
    });
    
    document.getElementById('enterBtn').addEventListener('click', () => {
        const quantity = parseInt(quantityInput.value) || 1;
        addItemToBill(currentSelectedItem, quantity);
        quantityModal.style.display = 'none';
    });
    
    closeModal.addEventListener('click', () => {
        quantityModal.style.display = 'none';
    });
    
    window.addEventListener('click', (event) => {
        if (event.target === quantityModal) {
            quantityModal.style.display = 'none';
        }
    });
    
    // Initialize with empty bill
    updateBillTable();
}

let currentSelectedItem = null;

function searchItem() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    if (searchTerm.length < 1) return;
    
    database.ref('items').orderByChild('id').startAt(searchTerm).endAt(searchTerm + '\uf8ff')
        .once('value')
        .then((snapshot) => {
            const items = snapshot.val();
            if (items) {
                const item = Object.values(items)[0];
                showQuantityModal(item);
            } else {
                // Search by name if not found by ID
                database.ref('items').orderByChild('name').startAt(searchTerm).endAt(searchTerm + '\uf8ff')
                    .once('value')
                    .then((snapshot) => {
                        const items = snapshot.val();
                        if (items) {
                            const item = Object.values(items)[0];
                            showQuantityModal(item);
                        }
                    });
            }
        });
}

function showQuantityModal(item) {
    currentSelectedItem = item;
    const modal = document.getElementById('quantityModal');
    document.getElementById('quantityInput').value = '1';
    modal.style.display = 'block';
}

function addItemToBill(item, quantity) {
    // Check if item already exists in bill
    const existingItemIndex = currentBillItems.findIndex(i => i.id === item.id);
    
    if (existingItemIndex >= 0) {
        // Update quantity if item exists
        currentBillItems[existingItemIndex].quantity += quantity;
    } else {
        // Add new item to bill
        currentBillItems.push({
            id: item.id,
            name: item.name,
            price: parseFloat(item.price),
            quantity: quantity
        });
    }
    
    updateBillTable();
    document.getElementById('searchInput').value = '';
    document.getElementById('searchInput').focus();
}

function updateBillTable() {
    const tableBody = document.getElementById('itemsTableBody');
    let html = '';
    let grandTotal = 0;
    
    currentBillItems.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        grandTotal += itemTotal;
        
        html += `
            <tr>
                <td>${item.id}</td>
                <td>${item.name}</td>
                <td class="quantity-changer">
                    <button onclick="changeQuantity(${index}, -1)">-</button>
                    ${item.quantity}
                    <button onclick="changeQuantity(${index}, 1)">+</button>
                </td>
                <td>Rs. ${item.price.toFixed(2)}</td>
                <td>Rs. ${itemTotal.toFixed(2)}</td>
                <td><button onclick="removeItem(${index})">Remove</button></td>
            </tr>
        `;
    });
    
    tableBody.innerHTML = html || '<tr><td colspan="6">No items added</td></tr>';
    document.getElementById('grandTotal').textContent = grandTotal.toFixed(2);
}

function changeQuantity(index, change) {
    const newQuantity = currentBillItems[index].quantity + change;
    if (newQuantity > 0) {
        currentBillItems[index].quantity = newQuantity;
        updateBillTable();
    } else {
        removeItem(index);
    }
}

function removeItem(index) {
    currentBillItems.splice(index, 1);
    updateBillTable();
}

function resetBilling() {
    if (currentBillItems.length > 0 && !confirm('Are you sure you want to cancel this bill?')) {
        return;
    }
    currentBillItems = [];
    updateBillTable();
}

function printBill() {
    if (currentBillItems.length === 0) {
        alert('No items to print!');
        return;
    }
    
    // In a real app, this would send to a printer
    // For demo, we'll just show a print preview
    const printContent = generatePrintContent();
    const printWindow = window.open('', '_blank');
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
}

function generatePrintContent() {
    const now = new Date();
    let itemsHtml = '';
    let grandTotal = 0;
    
    currentBillItems.forEach(item => {
        const itemTotal = item.price * item.quantity;
        grandTotal += itemTotal;
        
        itemsHtml += `
            <tr>
                <td>${item.name}</td>
                <td>${item.quantity}</td>
                <td>Rs. ${item.price.toFixed(2)}</td>
                <td>Rs. ${itemTotal.toFixed(2)}</td>
            </tr>
        `;
    });
    
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Bill Print</title>
            <style>
                body { font-family: Arial; width: 80mm; margin: 0 auto; }
                .header { text-align: center; margin-bottom: 10px; }
                .bill-info { margin-bottom: 10px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
                th, td { padding: 5px; text-align: left; border-bottom: 1px solid #ddd; }
                .total { text-align: right; font-weight: bold; margin-top: 10px; }
                .footer { margin-top: 20px; text-align: center; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h2>Gold Leaf Wine Store</h2>
                <p>Terminal: ${terminalId}</p>
            </div>
            
            <div class="bill-info">
                <p>Date: ${now.toLocaleDateString()}</p>
                <p>Time: ${now.toLocaleTimeString()}</p>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>
            
            <div class="total">
                Grand Total: Rs. ${grandTotal.toFixed(2)}
            </div>
            
            <div class="footer">
                <p>Thank you for your purchase!</p>
                <p>Please come again</p>
            </div>
        </body>
        </html>
    `;
}

function sendToAdmin() {
    if (currentBillItems.length === 0) {
        alert('No items to send!');
        return;
    }
    
    const now = new Date();
    const billId = `BILL_${now.getTime()}`;
    let grandTotal = 0;
    
    const billItems = currentBillItems.map(item => {
        grandTotal += item.price * item.quantity;
        return {
            id: item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity
        };
    });
    
    const billData = {
        terminal: terminalId,
        timestamp: now.getTime(),
        items: billItems,
        total: grandTotal,
        status: 'pending'
    };
    
    database.ref('bills/' + billId).set(billData)
        .then(() => {
            alert('Bill sent to admin for approval!');
            currentBillItems = [];
            updateBillTable();
        })
        .catch(error => {
            console.error('Error sending bill to admin: ', error);
            alert('Failed to send bill to admin. Please try again.');
        });
}

// QR Scanner functionality
let qrScanner = null;

function openQrScannerModal() {
    const modal = document.getElementById('qrScannerModal');
    modal.style.display = 'block';
    
    document.getElementById('startScannerBtn').addEventListener('click', startQrScanner);
    document.getElementById('stopScannerBtn').addEventListener('click', stopQrScanner);
    
    const closeModal = document.getElementsByClassName('close')[1];
    closeModal.addEventListener('click', () => {
        stopQrScanner();
        modal.style.display = 'none';
    });
    
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            stopQrScanner();
            modal.style.display = 'none';
        }
    });
}

function startQrScanner() {
    const video = document.getElementById('qrVideo');
    document.getElementById('startScannerBtn').disabled = true;
    document.getElementById('stopScannerBtn').disabled = false;
    
    // In a real app, you would use a QR scanning library like Instascan
    // This is a simplified version for demonstration
    
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            video.srcObject = stream;
            video.play();
            
            // Simulate QR code detection
            setTimeout(() => {
                // In a real app, this would be the actual QR code content
                const qrCode = '123'; // Sample QR code (item ID)
                database.ref('items/' + qrCode).once('value')
                    .then(snapshot => {
                        const item = snapshot.val();
                        if (item) {
                            stopQrScanner();
                            document.getElementById('qrScannerModal').style.display = 'none';
                            showQuantityModal(item);
                        } else {
                            alert('Item not found!');
                        }
                    });
            }, 2000);
        })
        .catch(err => {
            console.error('Error accessing camera: ', err);
            alert('Could not access camera. Please check permissions.');
        });
}

function stopQrScanner() {
    const video = document.getElementById('qrVideo');
    if (video.srcObject) {
        video.srcObject.getTracks().forEach(track => track.stop());
        video.srcObject = null;
    }
    document.getElementById('startScannerBtn').disabled = false;
    document.getElementById('stopScannerBtn').disabled = true;
}

// Initialize
loadBillingInterface();