// Firebase configuration
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "your-project.firebaseapp.com",
    databaseURL: "https://your-project.firebaseio.com",
    projectId: "your-project",
    storageBucket: "your-project.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();

// DOM Elements
const addItemBtn = document.getElementById('addItemBtn');
const inboxBtn = document.getElementById('inboxBtn');
const contentArea = document.getElementById('contentArea');

// Update datetime every second
setInterval(() => {
    document.getElementById('datetime').textContent = new Date().toLocaleString();
}, 1000);

// Event Listeners
addItemBtn.addEventListener('click', loadAddItemForm);
inboxBtn.addEventListener('click', loadInbox);

function loadAddItemForm() {
    contentArea.innerHTML = `
        <h2>Add New Item</h2>
        <form id="itemForm">
            <div class="form-group">
                <label for="itemId">Item ID (QR Code):</label>
                <input type="text" id="itemId" required>
            </div>
            <div class="form-group">
                <label for="itemName">Product Name:</label>
                <input type="text" id="itemName" required>
            </div>
            <div class="form-group">
                <label for="itemPrice">Price (Rs):</label>
                <input type="number" id="itemPrice" required>
            </div>
            <button type="submit">Add Item</button>
        </form>
        <div id="itemsList"></div>
    `;
    
    document.getElementById('itemForm').addEventListener('submit', addItem);
    loadItemsList();
}

async function addItem(e) {
    e.preventDefault();
    const id = document.getElementById('itemId').value;
    const name = document.getElementById('itemName').value;
    const price = document.getElementById('itemPrice').value;
    
    try {
        await database.ref('items/' + id).set({
            id: id,
            name: name,
            price: price
        });
        alert('Item added successfully!');
        loadItemsList();
    } catch (error) {
        console.error("Error adding item: ", error);
    }
}

function loadItemsList() {
    const itemsList = document.getElementById('itemsList');
    database.ref('items').on('value', (snapshot) => {
        const items = snapshot.val();
        let html = '<h3>Items List</h3><ul>';
        
        for (const id in items) {
            html += `
                <li>
                    ID: ${items[id].id} | 
                    Name: ${items[id].name} | 
                    Price: Rs.${items[id].price}
                    <button onclick="deleteItem('${id}')">Delete</button>
                </li>
            `;
        }
        
        html += '</ul>';
        itemsList.innerHTML = html;
    });
}

function deleteItem(id) {
    if (confirm('Are you sure you want to delete this item?')) {
        database.ref('items/' + id).remove()
            .then(() => console.log('Item deleted'))
            .catch(error => console.error("Error deleting item: ", error));
    }
}

function loadInbox() {
    contentArea.innerHTML = '<h2>Pending Bills</h2><div id="billsList"></div>';
    
    database.ref('bills').orderByChild('status').equalTo('pending').on('value', (snapshot) => {
        const bills = snapshot.val();
        let html = '';
        
        for (const billId in bills) {
            html += `
                <div class="bill-card">
                    <h3>Bill ID: ${billId}</h3>
                    <p>From: Terminal ${bills[billId].terminal}</p>
                    <p>Date: ${new Date(bills[billId].timestamp).toLocaleString()}</p>
                    <p>Total: Rs. ${bills[billId].total}</p>
                    <button onclick="viewBillDetails('${billId}')">View Details</button>
                    <button onclick="approveBill('${billId}')">Approve</button>
                </div>
            `;
        }
        
        document.getElementById('billsList').innerHTML = html || '<p>No pending bills</p>';
    });
}

function viewBillDetails(billId) {
    database.ref('bills/' + billId).once('value').then((snapshot) => {
        const bill = snapshot.val();
        let html = `
            <h3>Bill Details - ID: ${billId}</h3>
            <p>Terminal: ${bill.terminal}</p>
            <p>Date: ${new Date(bill.timestamp).toLocaleString()}</p>
            <h4>Items:</h4>
            <table>
                <tr>
                    <th>Item ID</th>
                    <th>Name</th>
                    <th>Qty</th>
                    <th>Price</th>
                    <th>Total</th>
                </tr>
        `;
        
        bill.items.forEach(item => {
            html += `
                <tr>
                    <td>${item.id}</td>
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>Rs. ${item.price}</td>
                    <td>Rs. ${item.price * item.quantity}</td>
                </tr>
            `;
        });
        
        html += `
            </table>
            <h4>Grand Total: Rs. ${bill.total}</h4>
            <button onclick="printBill('${billId}')">Print Bill</button>
            <button onclick="loadInbox()">Back to Inbox</button>
        `;
        
        contentArea.innerHTML = html;
    });
}

function approveBill(billId) {
    database.ref('bills/' + billId).update({ status: 'approved' })
        .then(() => {
            alert('Bill approved successfully!');
            loadInbox();
        })
        .catch(error => console.error("Error approving bill: ", error));
}

function printBill(billId) {
    // Implement print functionality
    window.print();
}

// Initialize
loadInbox();