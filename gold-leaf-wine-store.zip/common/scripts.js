// Common JavaScript functions
function showLoading() {
    // Show loading indicator
    document.body.innerHTML += '<div id="loading" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:1000;display:flex;justify-content:center;align-items:center;"><div style="background:white;padding:20px;border-radius:5px;">Loading...</div></div>';
}

function hideLoading() {
    // Hide loading indicator
    const loading = document.getElementById('loading');
    if (loading) loading.remove();
}

// Initialize with current datetime
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('datetime').textContent = new Date().toLocaleString();
});

// Error handling
window.addEventListener('error', (event) => {
    console.error('Error:', event.error);
    alert('An error occurred. Please check console for details.');
});