const express = require('express');
const admin = require('firebase-admin');
const cors = require('cors');
const serviceAccount = require('./serviceAccountKey.json');

// Initialize Firebase Admin
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://your-project.firebaseio.com"
});

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;

// API Endpoints
app.get('/api/items', async (req, res) => {
  try {
    const snapshot = await admin.database().ref('items').once('value');
    res.json(snapshot.val());
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/items', async (req, res) => {
  try {
    const { id, name, price } = req.body;
    await admin.database().ref('items/' + id).set({ id, name, price });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/bills', async (req, res) => {
  try {
    const { status } = req.query;
    let query = admin.database().ref('bills');
    
    if (status) {
      query = query.orderByChild('status').equalTo(status);
    }
    
    const snapshot = await query.once('value');
    res.json(snapshot.val());
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/bills', async (req, res) => {
  try {
    const billData = req.body;
    const billId = `BILL_${Date.now()}`;
    await admin.database().ref('bills/' + billId).set(billData);
    res.json({ success: true, billId });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/bills/:id/approve', async (req, res) => {
  try {
    const { id } = req.params;
    await admin.database().ref('bills/' + id).update({ status: 'approved' });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});