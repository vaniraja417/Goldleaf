const admin = require('firebase-admin');

// Initialize Firebase Admin (if not already initialized)
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(require('./serviceAccountKey.json')),
    databaseURL: "https://your-project.firebaseio.com"
  });
}

const db = admin.database();

// Helper functions
const getItems = async () => {
  const snapshot = await db.ref('items').once('value');
  return snapshot.val();
};

const addItem = async (item) => {
  await db.ref('items/' + item.id).set(item);
};

const deleteItem = async (id) => {
  await db.ref('items/' + id).remove();
};

const getPendingBills = async () => {
  const snapshot = await db.ref('bills').orderByChild('status').equalTo('pending').once('value');
  return snapshot.val();
};

const createBill = async (bill) => {
  const billId = `BILL_${Date.now()}`;
  await db.ref('bills/' + billId).set(bill);
  return billId;
};

const approveBill = async (billId) => {
  await db.ref('bills/' + billId).update({ status: 'approved' });
};

module.exports = {
  getItems,
  addItem,
  deleteItem,
  getPendingBills,
  createBill,
  approveBill
};